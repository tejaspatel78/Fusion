const express = require('express');
const router = express.Router();
const crudController = require('../controllers/crud')
const { verifyToken } = require('./../middlewares/verifyToken')
const { configCons } = require('./../lib/utils')

router.post(configCons.URL_CRUD_DELETE, crudController.deleteData);
router.post(configCons.URL_CRUD_UPDATE, verifyToken, crudController.updateData);
router.get(configCons.URL_CRUD_FETCH, crudController.fetchData);

module.exports = router;