const usersRoute = require('./user');
const forgotPassRoute = require('./forgot-password')
const resetPassRoute = require('./reset-password')
const updatePassRoute = require('./update-password')
const crudRoute = require('./crud')
const { configCons } = require('./../lib/utils')

module.exports = function(app) {
  app.use(configCons.PREFIX_API_FUSION, usersRoute)
  app.use(configCons.PREFIX_API_FUSION, forgotPassRoute)
  app.use(configCons.PREFIX_API_FUSION, resetPassRoute)
  app.use(configCons.PREFIX_API_FUSION, updatePassRoute)
  app.use(configCons.PREFIX_API_FUSION, crudRoute)
}
