const express = require('express');
const router = express.Router();
const userController = require('../controllers/user')
const { configCons } = require('./../lib/utils')

router.post(configCons.URL_USER_SIGNUP, userController.userSignup);
router.post(configCons.URL_USER_LOGIN, userController.userLogin);

module.exports = router;