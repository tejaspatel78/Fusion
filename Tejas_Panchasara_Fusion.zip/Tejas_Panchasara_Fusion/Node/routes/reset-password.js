const express = require('express');
const router = express.Router();
const resetPassController = require('../controllers/reset-password')
const { configCons } = require('./../lib/utils')

router.get(configCons.URL_RESET_PASSWORD, resetPassController.resetPassword);

module.exports = router;
