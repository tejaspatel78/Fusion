const express = require('express');
const router = express.Router();
const forgotPassController = require('../controllers/forgot-password')
const { configCons } = require('./../lib/utils')

router.post(configCons.URL_FORGOT_PASSWORD, forgotPassController.forgotPassword);

module.exports = router;
