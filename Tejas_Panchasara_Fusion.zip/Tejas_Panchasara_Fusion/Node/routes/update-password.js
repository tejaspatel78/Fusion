const express = require('express');
const router = express.Router();
const updatePassController = require('../controllers/update-password')
const { configCons } = require('./../lib/utils')

router.post(configCons.URL_UPDATE_PASSWORD, updatePassController.updatePassword);

module.exports = router;
