const { connectDb } = require('./../lib/utils')

const updatePassword = async (uid, newPassword) => {
    const con = await connectDb()
    return new Promise((resolve, reject) => {
        const query = 'update admin set password="' + newPassword + '" where uid=' + uid
        con.query(query, function (error, response) {
            if (error) reject(error);
            resolve(response)
        })
    })
}

module.exports = {
    updatePassword
}