const { connectDb, logger, generateToken, cryptr, configCons } = require('./../lib/utils')
const nodemailer = require('nodemailer')

const sendForgotPassMail = async (email) => {
    try {
        logger.debug('sendForgotPassMail() email: %s', email)
        const con = await connectDb()
        const user = await checkUserExists(email, con)
        if (user.length === 0) {
            return configCons.MSG_EMAIL_NOT_EXIST
        }
        const token = generateToken(user[0], user[0].uid, configCons.LINK_EXPIRE_TIME)
        console.log('token = ', token)
        const smtpTransport = nodemailer.createTransport({
            service: 'Gmail',
            auth: {
                user: 'tejaspatel686',
                pass: 'Patel@7878'
            }
        });

        const mailOptions = {
            to: email.toLowerCase(),
            from: 'tejaspatel686@gmail.com',
            subject: configCons.RESET_YOUR_PASSWORD,
            html: '<h4><b>Reset Password</b></h4><br>' +
                '<p>To reset your password, click here:</p>' +
                '<a href="http://localhost:3000/api/fusion/reset/password/' + cryptr.encrypt(user[0].uid) + '?token=' + token + '">Click me</a>' +
                '<br><br>'
        }
        const mailResponse = await smtpTransport.sendMail(mailOptions)
        return mailResponse
    } catch (error) {
        logger.warn(`Error while sendForgotPassMail(). Error = %j %s`, error, error)
        throw error
    }
}

const checkUserExists = async (email, con) => {
    return new Promise((resolve, reject) => {
        const query = 'select * from admin where email="' + email.toLowerCase() + '"'
        con.query(query, function (error, response) {
            if (error) reject(error);
            return resolve(response)
        })
    })
}

module.exports = {
    sendForgotPassMail
}