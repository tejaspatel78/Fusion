const { bcrypt, connectDb, logger, configCons } = require('./../lib/utils')

const insertUserData = async (reqPayload) => {
    try {
        logger.debug('insertUserData() reqPayload: %j', reqPayload)
        const con = await connectDb()
        const user = await checkUserExists(reqPayload.email, con)
        if (user.length > 0) {
            return configCons.MSG_ALREADY_EXIST
        }
        const [countryId, stateId, cityId] = await getCountryStateCityIds(reqPayload, con)
        const response = await insertUser(reqPayload, countryId, stateId, cityId, con)
        delete response[0].password
        return response
    }
    catch (error) {
        logger.warn(`Error while insertUserData(). Error = %j %s`, error, error)
        throw error
    }
}

const getCountryStateCityIds = async (reqPayload, con) => {
    return new Promise((resolve, reject) => {
        const query = 'select * from country where cname="' + reqPayload.country.toLowerCase() + '"';
        con.query(query, async function (error, response) {
            if (error) reject(error);
            if (response.length === 0) {
                const countryResponse = await insertCountry(reqPayload.country.toLowerCase(), con)
                const stateResponse = await insertState(reqPayload.state.toLowerCase(), countryResponse[0].cid, con)
                const cityResponse = await insertCity(reqPayload.city.toLowerCase(), stateResponse[0].sid, con)
                return resolve([countryResponse[0].cid, stateResponse[0].sid, cityResponse[0].city_id])
            } else if (response.length > 0) {
                const [stateId, cityId] = await processStateCityDetail(reqPayload, response[0].cid, con)
                return resolve([response[0].cid, stateId, cityId])
            }
        })
    })
}

const processStateCityDetail = async (reqPayload, countryId, con) => {
    return new Promise((resolve, reject) => {
        const query = 'select * from state where sname = "' + reqPayload.state.toLowerCase() + '" AND country_id = "' + countryId + '"';
        con.query(query, async function (error, response) {
            if (error) reject(error);
            if (response.length === 0) {
                const stateResponse = await insertState(reqPayload.state.toLowerCase(), countryId, con)
                const cityResponse = await insertCity(reqPayload.city.toLowerCase(), stateResponse[0].sid, con)
                return resolve([stateResponse[0].sid, cityResponse[0].city_id])
            } else if (response.length > 0) {
                const cityId = await processCityDetail(reqPayload, response[0].sid, con)
                return resolve([response[0].sid, cityId])
            }
        })
    })
}

const processCityDetail = async (reqPayload, stateId, con) => {
    return new Promise((resolve, reject) => {
        const query = 'select * from city where city_name = "' + reqPayload.city.toLowerCase() + '" AND state_id = "' + stateId + '"';
        con.query(query, async function (error, response) {
            if (error) reject(error);
            if (response.length === 0) {
                const cityResponse = await insertCity(reqPayload.city.toLowerCase(), stateId, con)
                return resolve(cityResponse[0].city_id)
            }
            return resolve(response[0].city_id)
        })
    })
}

const insertCity = async (cityName, stateId, con) => {
    return new Promise((resolve, reject) => {
        const query = 'insert into city (city_name, state_id) values ("' + cityName + '","' + stateId + '")'
        con.query(query, function (error) {
            if (error) reject(error);
            const cityQuery = 'select * from city where state_id = "' + stateId + '" AND city_name = "' + cityName + '"';
            con.query(cityQuery, function (error, response) {
                if (error) reject(error);
                return resolve(response)
            })
        })
    })
}

const insertState = async (stateName, countryId, con) => {
    return new Promise((resolve, reject) => {
        const query = 'insert into state (sname, country_id) values ("' + stateName + '","' + countryId + '")'
        con.query(query, function (error) {
            if (error) reject(error);
            const stateQuery = 'select * from state where sname = "' + stateName + '" AND country_id = "' + countryId + '"';
            con.query(stateQuery, function (error, response) {
                if (error) reject(error);
                return resolve(response)
            })
        })
    })
}

const insertCountry = async (countryName, con) => {
    return new Promise((resolve, reject) => {
        const query = 'insert into country (cname) values ("' + countryName + '")'
        con.query(query, function (error) {
            if (error) reject(error);
            const countryQuery = 'select * from country where cname="' + countryName + '"';
            con.query(countryQuery, function (error, response) {
                if (error) reject(error);
                return resolve(response)
            })
        })
    })
}

const insertUser = async (userDetail, countryId, stateId, cityId, con) => {
    return new Promise((resolve, reject) => {
        const query = 'insert into admin (uname, email, password, country_id, state_id, city_id) values ("' + userDetail.uname + '","' + userDetail.email.toLowerCase() + '","' + userDetail.password + '","' + countryId + '","' + stateId + '","' + cityId + '")'
        con.query(query, function (error) {
            if (error) reject(error);
            const userQuery = 'select * from admin where email="' + userDetail.email + '"';
            con.query(userQuery, function (error, response) {
                if (error) reject(error);
                return resolve(response)
            })
        })
    })
}

const userLogin = async (reqPayload) => {
    try {
        logger.debug('userLogin() reqPayload: %j', reqPayload)
        const con = await connectDb()
        const user = await checkUserExists(reqPayload.email, con)
        if (user.length === 0) {
            return configCons.MSG_USER_NOT_EXIST
        }
        if (!bcrypt.compareSync(reqPayload.password, user[0].password)) {
            return configCons.MSG_INVALID_PASSWORD
        }
        delete user[0].password
        return user
    }
    catch (error) {
        logger.warn(`Error while userLogin(). Error = %j %s`, error, error)
        throw error
    }
}

const checkUserExists = async (email, con) => {
    return new Promise((resolve, reject) => {
        const query = 'select * from admin where email="' + email.toLowerCase() + '"';
        con.query(query, function (error, response) {
            if (error) reject(error);
            return resolve(response)
        })
    })
}

module.exports = {
    insertUserData,
    userLogin
}