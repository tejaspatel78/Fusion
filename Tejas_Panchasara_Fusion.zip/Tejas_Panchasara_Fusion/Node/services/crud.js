const { connectDb, logger, configCons } = require('./../lib/utils')

const deleteData = async (reqPayload) => {
    try {
        logger.debug('deleteData() reqPayload: %j', reqPayload)
        const con = await connectDb()
        let response
        if (reqPayload.country) {
            response = await deleteCountryStateCity(reqPayload.country.toLowerCase(), con)
        } else if (reqPayload.state) {
            response = await deleteStateCity(reqPayload.state.toLowerCase(), con)
        } else if (reqPayload.city) {
            response = await deleteCity(reqPayload.city.toLowerCase(), con)
        }
        return response
    }
    catch (error) {
        logger.warn(`Error while deleteData(). Error = %j %s`, error, error)
        throw error
    }
}

const deleteCountryStateCity = async (countryName, con) => {
    return new Promise((resolve, reject) => {
        const query = 'DELETE country, state, city FROM city INNER JOIN state ON city.state_id = state.sid INNER JOIN country ON country.cid = state.country_id WHERE country.cname ="' + countryName + '"';
        con.query(query, function (error) {
            if (error) reject(error)
            return resolve()
        })
    })
}

const deleteStateCity = async (stateName, con) => {
    return new Promise((resolve, reject) => {
        const query = 'DELETE state, city FROM city INNER JOIN state ON city.state_id = state.sid WHERE state.sname = "' + stateName + '"';
        con.query(query, function (error) {
            if (error) reject(error)
            return resolve(configCons.MSG_DATA_DELETE_SUCCESSFULLY)
        })
    })
}

const deleteCity = async (cityName, con) => {
    return new Promise((resolve, reject) => {
        const query = 'DELETE FROM city WHERE city_name = "' + cityName + '"';
        con.query(query, function (error) {
            if (error) reject(error)
            return resolve(configCons.MSG_DATA_DELETE_SUCCESSFULLY)
        })
    })
}

const updateData = async (reqPayload, userCode) => {
    try {
        logger.debug('updateData() reqPayload: %j, userCode: %s', reqPayload, userCode)
        const con = await connectDb()
        const [countryId, stateId, cityId] = await getCountryStateCityIds(reqPayload, con)
        const response = await updateUserData(userCode, countryId, stateId, cityId, con)
        return response
    }
    catch (error) {
        logger.warn(`Error while updateData(). Error = %j %s`, error, error)
        throw error
    }
}

const updateUserData = async (userCode, countryId, stateId, cityId, con) => {
    return new Promise((resolve, reject) => {
        const query = 'update admin set country_id=' + countryId + ', state_id=' + stateId + ', city_id=' + cityId + ' where uid =' + userCode
        con.query(query, function (error, response) {
            if (error) reject(error);
            return resolve(configCons.MSG_USER_DATA_UPDATE_SUCCESSFULLY)
        })
    })
}

const getCountryStateCityIds = async (reqPayload, con) => {
    return new Promise((resolve, reject) => {
        const query = 'select * from country where cname="' + reqPayload.country.toLowerCase() + '"';
        con.query(query, async function (error, response) {
            if (error) reject(error);
            if (response.length === 0) {
                const countryResponse = await insertCountry(reqPayload.country.toLowerCase(), con)
                const stateResponse = await insertState(reqPayload.state.toLowerCase(), countryResponse[0].cid, con)
                const cityResponse = await insertCity(reqPayload.city.toLowerCase(), stateResponse[0].sid, con)
                return resolve([countryResponse[0].cid, stateResponse[0].sid, cityResponse[0].city_id])
            } else if (response.length > 0) {
                const [stateId, cityId] = await processStateCityDetail(reqPayload, response[0].cid, con)
                return resolve([response[0].cid, stateId, cityId])
            }
        })
    })
}

const processStateCityDetail = async (reqPayload, countryId, con) => {
    return new Promise((resolve, reject) => {
        const query = 'select * from state where sname = "' + reqPayload.state.toLowerCase() + '" AND country_id = "' + countryId + '"';
        con.query(query, async function (error, response) {
            if (error) reject(error);
            if (response.length === 0) {
                const stateResponse = await insertState(reqPayload.state.toLowerCase(), countryId, con)
                const cityResponse = await insertCity(reqPayload.city.toLowerCase(), stateResponse[0].sid, con)
                return resolve([stateResponse[0].sid, cityResponse[0].city_id])
            } else if (response.length > 0) {
                const cityId = await processCityDetail(reqPayload, response[0].sid, con)
                return resolve([response[0].sid, cityId])
            }
        })
    })
}

const processCityDetail = async (reqPayload, stateId, con) => {
    return new Promise((resolve, reject) => {
        const query = 'select * from city where city_name = "' + reqPayload.city.toLowerCase() + '" AND state_id = "' + stateId + '"';
        con.query(query, async function (error, response) {
            if (error) reject(error);
            if (response.length === 0) {
                const cityResponse = await insertCity(reqPayload.city.toLowerCase(), stateId, con)
                return resolve(cityResponse[0].city_id)
            }
            return resolve(response[0].city_id)
        })
    })
}

const insertCity = async (cityName, stateId, con) => {
    return new Promise((resolve, reject) => {
        const query = 'insert into city (city_name, state_id) values ("' + cityName + '","' + stateId + '")'
        con.query(query, function (error) {
            if (error) reject(error);
            const cityQuery = 'select * from city where state_id = "' + stateId + '" AND city_name = "' + cityName + '"';
            con.query(cityQuery, function (error, response) {
                if (error) reject(error);
                return resolve(response)
            })
        })
    })
}

const insertState = async (stateName, countryId, con) => {
    return new Promise((resolve, reject) => {
        const query = 'insert into state (sname, country_id) values ("' + stateName + '","' + countryId + '")'
        con.query(query, function (error) {
            if (error) reject(error);
            const stateQuery = 'select * from state where sname = "' + stateName + '" AND country_id = "' + countryId + '"';
            con.query(stateQuery, function (error, response) {
                if (error) reject(error);
                return resolve(response)
            })
        })
    })
}

const insertCountry = async (countryName, con) => {
    return new Promise((resolve, reject) => {
        const query = 'insert into country (cname) values ("' + countryName + '")'
        con.query(query, function (error) {
            if (error) reject(error);
            const countryQuery = 'select * from country where cname="' + countryName + '"';
            con.query(countryQuery, function (error, response) {
                if (error) reject(error);
                return resolve(response)
            })
        })
    })
}

const fetchData = async (payLoad) => {
    const con = await connectDb()
    return new Promise((resolve, reject) => {
        const searchQuery = 'select admin.uname AS user_name, admin.email, country.cname AS country_name, state.sname AS state_name, city.city_name FROM admin INNER JOIN state ON admin.state_id = state.sid INNER JOIN country ON country.cid = admin.country_id INNER JOIN city ON admin.city_id = city.city_id WHERE country.cname = "' + payLoad.searchKeyword + '" OR city.city_name = "' + payLoad.searchKeyword + '" OR state.sname = "' + payLoad.searchKeyword + '" ORDER BY ' + payLoad.column + ' ' + payLoad.sortOrder + ' LIMIT ' + payLoad.limit + ' OFFSET ' + payLoad.offset;
        con.query(searchQuery, function (error, response) {
            if (error) reject(error);
            return resolve(response)
        })
    })
}

module.exports = {
    deleteData,
    updateData,
    fetchData
}