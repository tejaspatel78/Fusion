const httpStatusCode = require('http-status-codes')
const { responseGenerators, logger, cryptr, bcrypt, configCons } = require('./../lib/utils')
const updatePassService = require('./../services/update-password')

const updatePassword = async (req, res) => {
    try {
        const userId = Number(cryptr.decrypt(req.params.uid))
        const newPassword = bcrypt.hashSync(req.body.newpass, 10)
        const response = await updatePassService.updatePassword(userId, newPassword)
        if (response.affectedRows > 0) {
            return res.send(configCons.MSG_PASSWORD_CHANGED)
        }
        return res.send(configCons.MSG_PROBLEM_CHANGE_PASSWORD)
    } catch (error) {
        logger.warn(`Error while updating password. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, configCons.MSG_ERROR_UPDATE_PASSWORD, true))
    }
}

module.exports = {
    updatePassword
}