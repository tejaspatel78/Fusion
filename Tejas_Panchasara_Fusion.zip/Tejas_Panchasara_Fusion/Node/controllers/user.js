const userService = require('../services/user')
const httpStatusCode = require('http-status-codes')
const { responseGenerators, bcrypt, generateToken, logger, configCons } = require('./../lib/utils')
const { schemaForSignup, schemaForLogin } = require('./../lib/validation')

const userSignup = async (req, res) => {
    try {
        const validationRes = schemaForSignup.validate(req.body)
        if (validationRes.error) {
            return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, validationRes.error.details[0], true))
        }
        req.body.password = bcrypt.hashSync(req.body.password, 10)
        const response = await userService.insertUserData(req.body)
        if (Array.isArray(response) && response.length > 0) {
            const token = generateToken(response[0], response[0].uid, configCons.USER_TOKEN_EXPIRE_TIME)
            return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, configCons.MSG_USER_REGISTERED_SUCCESSFULLY, false, token))
        }
        return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, response, false))
    } catch (error) {
        logger.warn(`Error while registering user. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, configCons.MSG_ERROR_SIGNUP, true))
    }
}

const userLogin = async (req, res) => {
    try {
        const validationRes = schemaForLogin.validate(req.body)
        if (validationRes.error) {
            return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, validationRes.error.details[0], true))
        }
        const response = await userService.userLogin(req.body)
        if (Array.isArray(response) && response.length > 0) {
            const token = generateToken(response[0], response[0].uid, configCons.USER_TOKEN_EXPIRE_TIME)
            return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, configCons.MSG_USER_LOGIN_SUCCESSFULLY, false, token))
        }
        return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, response, false))
    } catch (error) {
        logger.warn(`Error while loging user. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, configCons.MSG_ERROR_LOGIN, true))
    }
}

module.exports = {
    userSignup,
    userLogin
}