const forgotPassService = require('../services/forgot-password')
const httpStatusCode = require('http-status-codes')
const { responseGenerators, logger, configCons } = require('./../lib/utils')
const { schemaForForgotPassword } = require('./../lib/validation')

const forgotPassword = async (req, res) => {
    try {
        const validationRes = schemaForForgotPassword.validate(req.body)
        if (validationRes.error) {
            return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, validationRes.error.details[0], true))
        }
        const email = req.body.email
        const response = await forgotPassService.sendForgotPassMail(email)
        if (response.accepted.length > 0) {
            return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, configCons.MSG_FORGOT_PASSWORD_MAIL_SENT_SUCCESFULLY, false))
        }
        return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, response, false))
    } catch (error) {
        logger.warn(`Error while sending forgot password mail. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, configCons.MSG_ERROR_SENDING_FORGOT_PASSWORD_MAIL, true))
    }
}

module.exports = {
    forgotPassword
}