const jwt = require('jsonwebtoken')
const httpStatusCode = require('http-status-codes')
const { responseGenerators, logger, cryptr, configCons } = require('./../lib/utils')

const resetPassword = async (req, res) => {
    try {
        const userId = cryptr.decrypt(req.params.uid)
        const token = req.query.token
        await verifyResetPassToken(token, userId, res)
        let html = ''
        html += "<head><script>function checkform() { if (document.getElementById('npass').value !== document.getElementById('cpass').value) { alert('Password mismatch !'); return false; } return true; } </script></head>"
        html += "<body>"
        html += "<form action='/api/fusion/update/password/" + req.params.uid + "'  method='post' name='form1' onSubmit='return checkform()'>"
        html += "New Password:</span><input type='password' id='npass' name='newpass'><br>"
        html += "Confirm Password:</span><input type='password' id='cpass' name='confirmpass'>"
        html += "<input type='submit' value='submit'>"
        html += "<input type='reset' value='reset'>"
        html += "</form>"
        html += "</body>"
        return res.send(html)
    } catch (error) {
        logger.warn(`Error while resetting password. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, configCons.MSG_ERROR_RESET_PASSWORD, true))
    }
}

const verifyResetPassToken = async (token, userId, res) => {
    try {
        jwt.verify(token, userId, function (error) {
            if (error) {
                return res.send(configCons.MSG_ACTION_NOT_ALLOWED)
            }
        })
    } catch (error) {
        logger.warn(`Error while verifing token : %j %s`, error, error)
        return res.send(configCons.MSG_ERROR_VERIFY_TOKEN)
    }
}

module.exports = {
    resetPassword
}