const crudService = require('../services/crud')
const httpStatusCode = require('http-status-codes')
const { responseGenerators, logger, configCons } = require('./../lib/utils')
const { schemaForDeleteData, schemaForUpdateData, schemaForFetchData } = require('./../lib/validation')

const deleteData = async (req, res) => {
    try {
        const validationRes = schemaForDeleteData.validate(req.body)
        if (validationRes.error) {
            return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, validationRes.error.details[0], true))
        }
        const response = await crudService.deleteData(req.body)
        return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, response, false))
    } catch (error) {
        logger.warn(`Error while deleting data. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, configCons.MSG_ERROR_DELETE_DATA, true))
    }
}

const updateData = async (req, res) => {
    try {
        const validationRes = schemaForUpdateData.validate(req.body)
        if (validationRes.error) {
            return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, validationRes.error.details[0], true))
        }
        const userCode = req.headers.user_code
        const response = await crudService.updateData(req.body, userCode)
        return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, response, false))
    } catch (error) {
        logger.warn(`Error while updating data. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, configCons.MSG_ERROR_UPDATE_DATA, true))
    }
}

const fetchData = async (req, res) => {
    try {
        const payLoad = {}
        payLoad.offset = (Number(req.query.start) - 1)
        payLoad.limit = Number(req.query.limit)
        payLoad.searchKeyword = req.body.text
        payLoad.column = Object.keys(req.query.sort)[0]
        payLoad.sortOrder = req.query.sort[payLoad.column]
        
        const validationRes = schemaForFetchData.validate(payLoad)
        if (validationRes.error) {
            return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, validationRes.error.details[0], true))
        }
        const response = await crudService.fetchData(payLoad)
        return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, configCons.MSG_DATA_FETCH_SUCCESSFULLY, false))
    } catch (error) {
        logger.warn(`Error while fetching data. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, configCons.MSG_ERROR_FETCH_DATA, true))
    }
}

module.exports = {
    deleteData,
    updateData,
    fetchData
}