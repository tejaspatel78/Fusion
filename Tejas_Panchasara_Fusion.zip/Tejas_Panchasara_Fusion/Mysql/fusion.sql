-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2020 at 08:10 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fusion`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `uid` int(20) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(256) NOT NULL,
  `country_id` int(10) NOT NULL,
  `state_id` int(10) NOT NULL,
  `city_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`uid`, `uname`, `email`, `password`, `country_id`, `state_id`, `city_id`) VALUES
(24, 'bhaumik', 'bhaumik@20minutemail.it', '$2a$10$4EwHh76/2LxtWjJds/vvYu/exgD2bVEILUmbP9J53tq8IhMRAp3Nq', 9, 17, 28),
(25, 'nehal', 'nehal@20minutemail.it', '$2a$10$d9zIOmlXSY7kNJh5fz7d4eBEOH.ITJ10PeP0F8UWhaHOZrkaUQkYy', 9, 15, 26),
(26, 'nilesh', 'nilesh@20minutemail.it', '$2a$10$uN7fiDFqKa0rhNdkkR7PeO9Ua3TwCZuuWunZBBfVW326GPm/qcQy.', 9, 18, 29),
(27, 'karan', 'karan@20minutemail.it', '$2a$10$su3rDqvb.yyF3Wx6U1Zyj.KAyeH09mZLb5u9pIKdhsAyg751GlZ7C', 9, 18, 30),
(28, 'raj', 'raj@20minutemail.it', '$2a$10$qzJnRJC9IeXycUhMz.XZv.cdm7O0nbPvc4nXky9w2Sx.l1/MR9ITO', 9, 17, 28),
(29, 'hina', 'hina@20minutemail.it', '$2a$10$AELegl2rSDvgX6mxUszZAOqIxaG5LW48xnkjkgyx1yLHVFZEEPjEy', 9, 17, 31),
(30, 'ravi', 'ravi@20minutemail.it', '$2a$10$g02d6V1Zf0hiyJBzAAIpC.0.mlccweDw.YXCkd7V7Xa.Y8DfE88m6', 10, 16, 27),
(31, 'yash', 'yash@20minutemail.it', '$2a$10$RYw3xHOP5pIZX5HdWRXl..8Lixj8j3DGTBSQrLLNQ9gXGZbTM8.nG', 9, 19, 33);

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `city_id` int(10) NOT NULL,
  `city_name` varchar(50) NOT NULL,
  `state_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `city_name`, `state_id`) VALUES
(25, 'rajkot', 15),
(26, 'surat', 15),
(27, 'berlin', 16),
(28, 'amritsar', 17),
(29, 'pune', 18),
(30, 'mumbai', 18),
(31, 'sahranpur', 17),
(32, 'ny', 16);

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `cid` int(10) NOT NULL,
  `cname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`cid`, `cname`) VALUES
(9, 'india'),
(10, 'america');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `sid` int(10) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `country_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`sid`, `sname`, `country_id`) VALUES
(15, 'gujarat', 9),
(16, 'newyork', 10),
(17, 'punjab', 9),
(18, 'maharastra', 9),
(19, 'bihar', 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `uid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `city_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `cid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `sid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
